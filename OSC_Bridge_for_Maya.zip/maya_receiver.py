import maya.cmds as cmds
import maya.mel as mel

def setup_command_port(port=12000):
    try:
        cmds.commandPort(name=f":{port}", close=True)
    except:
        pass
    cmds.commandPort(name=f":{port}", sourceType="python")
    print(f"Command port opened on port {port}")
    return port

def create_data_reader_node():
    if cmds.objExists("dataReader"):
        print("dataReader node already exists")
        return "dataReader"
    node = cmds.createNode("transform", name="dataReader")
    keyable_attrs = cmds.listAttr(node, keyable=True) or []
    for attr in keyable_attrs:
        try:
            cmds.setAttr(f"{node}.{attr}", lock=False, keyable=False, channelBox=False)
            cmds.setAttr(f"{node}.{attr}", lock=True)
        except:
            pass
    print(f"Created dataReader node")
    return node

def check_command_port(port=12000):
    return False

def toggle_command_port(port_field, status_text):
    port = cmds.intField(port_field, query=True, value=True)
    port_name = f":{port}"
    current_status = cmds.text(status_text, query=True, label=True)
    is_open = "OPEN" in current_status
    if is_open:
        for p in [f":{port}", f"localhost:{port}", f"127.0.0.1:{port}"]:
            try:
                cmds.commandPort(name=p, close=True)
                print(f"Closed {p}")
            except:
                pass
        cmds.text(status_text, edit=True, label="Port Status: CLOSED", backgroundColor=(0.8, 0.3, 0.3))
    else:
        try:
            try:
                cmds.commandPort(name=port_name, close=True)
            except:
                pass
            try:
                cmds.commandPort(name=f"localhost:{port}", sourceType="python")
                cmds.text(status_text, edit=True, label="Port Status: OPEN", backgroundColor=(0.3, 0.8, 0.3))
                print(f"Command port {port} opened on localhost")
            except:
                cmds.commandPort(name=port_name, sourceType="python")
                cmds.text(status_text, edit=True, label="Port Status: OPEN", backgroundColor=(0.3, 0.8, 0.3))
                print(f"Command port {port} opened")
        except Exception as e:
            error_msg = str(e)
            print(f"Error opening port: {error_msg}")
            if "10048" in error_msg or "already in use" in error_msg.lower():
                cmds.text(status_text, edit=True, label="Port Status: IN USE", backgroundColor=(0.8, 0.8, 0.3))
                cmds.warning(f"Port {port} is already in use. Try a different port number or close other Maya instances.")
            else:
                cmds.text(status_text, edit=True, label="Port Status: ERROR", backgroundColor=(0.8, 0.8, 0.3))

def force_reset_port(port_field, status_text):
    port = cmds.intField(port_field, query=True, value=True)
    port_formats = [f":{port}", f"localhost:{port}", f"127.0.0.1:{port}"]
    for port_name in port_formats:
        try:
            cmds.commandPort(name=port_name, close=True)
            print(f"Closed {port_name}")
        except:
            pass
    cmds.text(status_text, edit=True, label="Port Status: CLOSED", backgroundColor=(0.8, 0.3, 0.3))
    print(f"Force reset port {port}")

def create_sensor_ui():
    window_name = "sensorControlWindow"
    if cmds.window(window_name, exists=True):
        cmds.deleteUI(window_name)
    window = cmds.window(window_name, title="Bridge Control", widthHeight=(300, 250))
    cmds.columnLayout(adjustableColumn=True, rowSpacing=10)
    cmds.text(label="Maya Bridge Receiver", font="boldLabelFont")
    cmds.separator(height=20)
    cmds.text(label="Command Port:")
    port_field = cmds.intField("portField", value=12000, width=100)
    status_text = cmds.text("portStatus", label="Port Status: CHECKING...", backgroundColor=(0.5, 0.5, 0.5), height=25)
    def update_status():
        cmds.text(status_text, edit=True, label="Port Status: CLOSED", backgroundColor=(0.8, 0.3, 0.3))
    cmds.button(label="Toggle Command Port", command=lambda x: toggle_command_port(port_field, status_text), backgroundColor=(0.5, 0.5, 0.7))
    cmds.button(label="Force Reset Port", command=lambda x: force_reset_port(port_field, status_text), backgroundColor=(0.7, 0.5, 0.5), annotation="Force close all port variations")
    cmds.button(label="Create Data Reader Node", command=lambda x: create_data_reader_node())
    cmds.separator(height=20)
    record_status = cmds.text("recordStatus", label="Recording: OFF", backgroundColor=(0.5, 0.5, 0.5), height=25)
    def toggle_recording(status_text):
        if not cmds.objExists("dataReader"):
            cmds.warning("Please create Data Reader Node first!")
            return
        if not cmds.attributeQuery("recordingEnabled", node="dataReader", exists=True):
            cmds.addAttr("dataReader", longName="recordingEnabled", attributeType="bool", defaultValue=False)
        if not cmds.attributeQuery("captureEnabled", node="dataReader", exists=True):
            cmds.addAttr("dataReader", longName="captureEnabled", attributeType="bool", defaultValue=True)
        current_state = cmds.getAttr("dataReader.recordingEnabled")
        new_state = not current_state
        cmds.setAttr("dataReader.recordingEnabled", new_state)
        if new_state:
            cmds.text(status_text, edit=True, label="Recording: ON", backgroundColor=(0.8, 0.3, 0.3))
            cmds.autoKeyframe(state=True)
            cmds.setAttr("dataReader.captureEnabled", True)
            cmds.play(forward=True)
            print("Recording started - Auto-keyframe enabled, Timeline playing")
        else:
            cmds.text(status_text, edit=True, label="Recording: OFF", backgroundColor=(0.5, 0.5, 0.5))
            cmds.autoKeyframe(state=False)
            cmds.setAttr("dataReader.captureEnabled", False)
            cmds.play(state=False)
            print("Recording stopped - Auto-keyframe disabled, Timeline stopped, Capture disabled")
    cmds.button(label="Toggle Recording", command=lambda x: toggle_recording(record_status), backgroundColor=(0.7, 0.5, 0.5))
    cmds.separator(height=10)
    cmds.button(label="Go to Start Frame", command=lambda x: cmds.currentTime(cmds.playbackOptions(query=True, minTime=True)))
    cmds.showWindow(window)
    cmds.evalDeferred(update_status)

def setup_all():
    mel.eval('scriptEditorInfo -suppressResults true -suppressInfo true;')
    node = create_data_reader_node()
    create_sensor_ui()
    cmds.autoKeyframe(state=False)
    mel.eval('scriptEditorInfo -suppressResults false -suppressInfo false;')
    print("\n=== Setup Complete ===")
    print("1. Use 'Toggle Command Port' button to open/close the port")
    print(f"2. DataReader node created: {node}")
    print("3. Auto-keyframing is disabled (will enable when recording)")
    print("4. Start the Python OSC bridge application")
    print("5. Manually connect sensor data to objects as needed")
    print("=====================\n")



if __name__ == "__main__":
    setup_all()
